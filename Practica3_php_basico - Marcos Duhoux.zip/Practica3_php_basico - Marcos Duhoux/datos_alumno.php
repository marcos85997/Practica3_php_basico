<?php

$nombre = $_GET['nombre'];
$telefono = $_GET['telefono'];
$matriculado = $_GET['matriculado'];
$ensenanza = $_GET['ensenanza'];
$mostrar = $_GET['mostrar'];

if($matriculado){
    $matriculado_frase = "está matriculado";
}
else{
    $matriculado_frase = "no está matriculado actualmente";
}

if($ensenanza == 'sec'){
    $ensenanza_frase = "secundaria";
}
else if($ensenanza == 'bach'){
    $ensenanza_frase = "bachillerato";
}
else if($ensenanza == 'cmedio'){
    $ensenanza_frase = "un ciclo medio";
}
else if($ensenanza == 'csup'){
    $ensenanza_frase = "un ciclo superior";
}

$frasefinal = "El alumno <b>$nombre</b>, con teléfono <b>$telefono</b>, <b>$matriculado_frase</b> en <b>$ensenanza_frase</b>.";

if ($mostrar == 0){
    print "<p>$frasefinal</p>";
}

else{
//control de errores
// Comprobar que el archivo existe o crearlo si no existe
$archivo = 'datos.txt';
if (!file_exists($archivo)) {
    fopen($archivo, 'w'); // crea el archivo vacio
}

// Abrir el archivo en modo escritura y agregar los datos
$file = fopen($archivo, 'a');
fwrite($file, "$frasefinal" . PHP_EOL);
fclose($file);

    print "<p>Datos guardados correctamente.</p>";
    print '<p><a href="mostrardatos.php">Mostrar archivo</a></p>';
}
?>