<?php
$dado1 = rand(1,6);
$dado2 = rand(1,6);
$dado3 = rand(1,6);
$dado4 = rand(1,6);
$dado5 = rand(1,6);

print "<h2>Jugador 1</h2>";
print "   <p>";
print "     <img src='img/$dado1.jpg' height=140>";
print "     <img src='img/$dado2.jpg' height=140>";
print "     <img src='img/$dado3.jpg' height=140>";
print "     <img src='img/$dado4.jpg' height=140>";
print "     <img src='img/$dado5.jpg' height=140>";
print "   </p>";

$dado6 = rand(1,6);
$dado7 = rand(1,6);
$dado8 = rand(1,6);
$dado9 = rand(1,6);
$dado10 = rand(1,6);

print "<h2>Jugador 2</h2>";
print "   <p>";
print "     <img src='img/$dado6.jpg' height=140>";
print "     <img src='img/$dado7.jpg' height=140>";
print "     <img src='img/$dado8.jpg' height=140>";
print "     <img src='img/$dado9.jpg' height=140>";
print "     <img src='img/$dado10.jpg' height=140>";
print "   </p>";

print "<h2>Resultado</h2>";

$puntj1=$dado1+$dado2+$dado3+$dado4+$dado5;
$puntj2=$dado6+$dado7+$dado8+$dado9+$dado10;

if ($puntj1 > $puntj2){
    print " Gana el jugador <b>1</b>";
}

elseif ($puntj1 < $puntj2){
    print " Gana el jugador <b>2</b>";
}

else{
    print " Empate";
}
?>