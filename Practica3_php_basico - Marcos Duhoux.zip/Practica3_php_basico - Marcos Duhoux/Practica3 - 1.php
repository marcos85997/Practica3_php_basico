<?php
$ancho = intval($_REQUEST['ancho']);
$alto = intval($_REQUEST['alto']);

print "<h1>Cuadrado</h1>";
for ($i = 1; $i <= $alto; $i++){
    for ($j = 1; $j <= $ancho; $j++){
        print "* ";
    }
    print "<br>";
}
?>