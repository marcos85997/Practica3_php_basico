<?php
$nombre = $_GET['nombre'];
$trabajo = $_GET['trabajo'];
$telefono = $_GET['telefono'];
$direccion = $_GET['direccion'];
$otras = $_GET['otras'];
$boton = $_GET['boton'];

if($boton=="Guardar"){
    $abrirarchivo = fopen("contactos.txt", "a");
    if($abrirarchivo){
        $linea = $nombre . ":" . $trabajo . ":" . $telefono . ":" . $direccion . ":" . $otras . "\n";
        fwrite($abrirarchivo, $linea);
        fclose($abrirarchivo);
        print "Contacto guardado.";
    }
}

if($boton == "Mostrar"){
    if(file_exists("contactos.txt")){
        $archivo = 'contactos.txt';
        $contenido = file_get_contents($archivo);
        echo "<pre>" . $contenido . "</pre>";
    }

    else {
    echo "No hay contactos guardados.";
    }
}

if($boton=="Buscar"){
    $nombreBuscado = $_GET['nombre'];
    $archivo = 'contactos.txt';
    $file = fopen($archivo, 'r');
    $encontrado = false;

    while (!feof($file)){
        $linea = trim(fgets($file));

        if (!empty($linea)){

            $partes = explode(':', $linea);

            $nombre_archivo = trim($partes[0]);
            $trabajo_archivo = trim($partes[1]);
            $telefono_archivo = trim($partes[2]);
            $direccion_archivo = trim($partes[3]);
            $otras_archivo = trim($partes[4]);

            if (strcmp($nombreBuscado, $nombre_archivo) === 0){
                echo "<h2>¡Contacto Encontrado!</h2>";
                echo "Nombre: " . $nombre_archivo . "<br>";
                echo "Trabajo: " . $trabajo_archivo . "<br>";
                echo "Teléfono: " . $telefono_archivo . "<br>";
                echo "Dirección: " . $direccion_archivo . "<br>";
                echo "Otras: " . $otras_archivo . "<br>"; 

                $encontrado = true;
                break;
            }
        }
    }

    fclose($file);

    if (!$encontrado){
        echo "No se encontró ningún contacto para el nombre " . htmlspecialchars($nombreBuscado) . ".";
    }
}
?>